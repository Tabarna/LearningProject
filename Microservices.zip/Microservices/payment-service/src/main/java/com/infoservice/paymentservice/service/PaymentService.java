package com.infoservice.paymentservice.service;

import com.infoservice.paymentservice.entity.Payment;
import com.infoservice.paymentservice.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Random;
import java.util.UUID;

@Service
public class PaymentService {
    @Autowired
    private PaymentRepository paymentRepository;


    public Payment dopayment(Payment payment){
        payment.setPaymentStatus(paymentprocessing());
        payment.setTransactionId(UUID.randomUUID().toString());
        return paymentRepository.save(payment);
    }

    public String paymentprocessing(){
        return new Random().nextBoolean()?"success":"false";
    }
}
